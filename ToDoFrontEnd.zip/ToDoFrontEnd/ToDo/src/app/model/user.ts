export interface User {
  id?: number;
  username: string;
  password?: string; // Optional if not required in frontend later
}
