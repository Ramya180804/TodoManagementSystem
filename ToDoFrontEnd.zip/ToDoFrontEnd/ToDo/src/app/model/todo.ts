import { User } from "./user";


export interface Todo {
  id?: number;
  task: string;
  completed: boolean;
  user?: User; // Optional in frontend if only needed for submission
}
