import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

   private baseUrl = 'http://localhost:8081/api';

  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  // Register a new user
 register(user: User): Observable<any> {
  return this.http.post(`${this.baseUrl}/register`, user, {
    withCredentials: true,
    responseType: 'text' // ✅ FIX: tells Angular to expect plain text
  });
}

 login(user: User): Observable<any> {
  return this.http.post(`${this.baseUrl}/login`, user, {
    withCredentials: true,
    responseType: 'text'  // ✅ Fix: Angular expects plain text
  });
}

  // Logout: remove session
  logout(): Observable<void> {
    localStorage.removeItem('username');
    this.router.navigate(['/login']);
    return of();
  }

  // Check if user is logged in
  isLoggedIn(): boolean {
    return localStorage.getItem('username') !== null;
  }

  // Get current logged-in username
  getLoggedInUsername(): string | null {
    return localStorage.getItem('username');
  }
}