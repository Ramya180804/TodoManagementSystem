import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Todo } from '../../model/todo';
import { TodoService } from '../../services/todo-service';


@Component({
  selector: 'app-todo-list',
  standalone: false,
  templateUrl: './todo-list.html',
  styleUrl: './todo-list.css'
})
export class TodoList implements OnInit {
  todos: Todo[] = [];
  hasData = false;
  editingTodo: Todo | null = null;

  constructor(
    private todoService: TodoService,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.loadTodos();
  }

  loadTodos(): void {
    this.todoService.getTodos().subscribe({
      next: (data) => {
        setTimeout(() => {
          this.todos = data;
          this.hasData = this.todos.length > 0;
        });
      },
      error: () => {
        this.toastr.error('Failed to load todos');
      }
    });
  }

  onEdit(todo: Todo): void {
    this.editingTodo = { ...todo };
  }

  onDelete(id?: number): void {
    if (!id) return;
    if (confirm('Are you sure you want to delete?')) {
      this.todoService.deleteTodo(id).subscribe({
        next: () => {
          this.toastr.success('ToDo deleted');
          this.loadTodos();
        },
        error: () => {
          this.toastr.error('Failed to delete');
        }
      });
    }
  }

  onFormSubmit(): void {
    this.editingTodo = null;
    this.loadTodos();
  }

  cancelEdit(): void {
    this.editingTodo = null;
  }
}