import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Todo } from '../../model/todo';
import { TodoService } from '../../services/todo-service';

@Component({
  selector: 'app-todo-form',
  standalone: false,
  templateUrl: './todo-form.html',
  styleUrl: './todo-form.css'
})
export class TodoForm implements  OnInit, OnChanges {
  @Input() todo: Todo | null = null;
  @Output() saved = new EventEmitter<void>();

  form!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private todoService: TodoService,  // ✅ correct service injected
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      id: [],
      task: ['', Validators.required],
      completed: [false]
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['todo'] && this.todo) {
      this.form.patchValue(this.todo);
    }
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    const todoData = this.form.value as Todo;

    if (todoData.id) {
      // ✅ Update
      this.todoService.updateTodo(todoData).subscribe({
        next: () => {
          this.toastr.success('Todo updated');
          this.saved.emit();
          this.form.reset({ completed: false });
        },
        error: () => this.toastr.error('Update failed')
      });
    } else {
      // ✅ Add
      this.todoService.addTodo(todoData).subscribe({
        next: () => {
          this.toastr.success('Todo added');
          this.saved.emit();
          this.form.reset({ completed: false });
        },
        error: () => this.toastr.error('Add failed')
      });
    }
  }
}